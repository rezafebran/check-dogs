import asyncio
import aiohttp

RESET = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"

# ASCII Art
ascii_art = r"""
< Dogs House Bot >
 ---------------
        \   ^__^
         \  (oo)\_______
            (__)\       )\/\
                ||----w |
                ||     ||
                                                    
"""

print(ascii_art)

async def get_task(user_id, reference):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://api.onetime.dog/tasks?user_id={user_id}&reference={reference}") as response:
                return await response.json()
    except Exception as err:
        print(f"{RED}Error fetching tasks: {err}{RESET}")
        return None

async def get_task(user_id, reference):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://api.onetime.dog/tasks?user_id={user_id}&reference={reference}") as response:
                return await response.json()
    except Exception as err:
        print(f"{RED}Error fetching tasks: {err}{RESET}")
        return None

async def verify_task(user_id, reference, username, index, check_balance_only):
    try:
        print(f"{BOLD}{CYAN}🔍 Checking account {index}: {username} {RESET}")
        if not check_balance_only:
            task = await get_task(user_id, reference)
            if task:
                for slug in task:
                    config = {
                        "url": f"https://api.onetime.dog/tasks/verify?task={slug['slug']}&user_id={user_id}&reference={reference}",
                        "method": "POST",
                        "headers": {
                            "accept": "application/json",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "no-cache",
                            "content-type": "text/plain;charset=UTF-8",
                            "pragma": "no-cache",
                            "priority": "u=1, i",
                            "sec-ch-ua": '"Not/A)Brand";v="8", "Chromium";v="126", "Microsoft Edge";v="126", "Microsoft Edge WebView2";v="126"',
                            "sec-ch-ua-mobile": "?0",
                            "sec-ch-ua-platform": '"Windows"',
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-site",
                            "Referer": "https://onetime.dog/",
                            "Referrer-Policy": "strict-origin-when-cross-origin",
                        },
                    }

                    if slug['slug'] != "invite-frens":
                        async with aiohttp.ClientSession() as session:
                            async with session.post(config['url'], headers=config['headers']) as response:
                                response_data = await response.json()
                                if response_data.get('success'):
                                    print(f"{GREEN}✔️ Completed task {slug['slug']} for user {username}{RESET}")
                                else:
                                    error_code = response_data.get('error_code')
                                    error_message = response_data.get('error_message')
                                    print(f"{RED}❌ {slug['slug']} failed with error code: {error_code} {RESET}")
                        await asyncio.sleep(5)

        total = await get_rewards_user(user_id)
        formatted_total = format(total, ',') if total is not None else 'N/A'
        print(f"{YELLOW}💰 Balance for user {username}: {formatted_total}{RESET}")
        if not check_balance_only:
            print(f"{BOLD}{CYAN}Finished checking account for user {username}{RESET}")
            print(f"{BOLD}================= Next Account ================={RESET}\n")
        return total
    except Exception as err:
        print(f"{RED}Error processing account {username}: {err}{RESET}")
        return None

async def get_rewards_user(user_id):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://api.onetime.dog/rewards?user_id={user_id}") as response:
                data = await response.json()
                return data.get('total')
    except Exception as err:
        print(f"{RED}Error fetching rewards: {err}{RESET}")
        return None

async def main():
    try:
        
        print(f"{BOLD}{CYAN}")
        print("╔═══════════════════════════════╗")
        print("║       Select operation mode   ║")
        print("╠═══════════════════════════════╣")
        print("║ 1. Check balance only         ║")
        print("║ 2. Perform tasks              ║")
        print("╚═══════════════════════════════╝")
        print(f"{RESET}")

        choice = input("Enter 1 or 2: ")

        check_balance_only = choice == '1'

        total_balance = 0
        with open('data.txt', 'r') as file:
            lines = file.readlines()
            for index, line in enumerate(lines, start=1):
                user_id, reference, username = line.strip().split('|')
                balance = await verify_task(user_id, reference, username, index, check_balance_only)
                if balance is not None:
                    total_balance += balance
        formatted_total_balance = format(total_balance, ',')
        if check_balance_only:
            print(f"{BOLD}{CYAN}🌟 Total Balance for all users: {formatted_total_balance} 🦴 Dogs!{RESET}")
    except Exception as err:
        print(f"{RED}Error reading data.txt: {err}{RESET}")

if __name__ == "__main__":
    asyncio.run(main())
